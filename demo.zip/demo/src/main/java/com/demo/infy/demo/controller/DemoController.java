package com.demo.infy.demo.controller;

import com.demo.infy.demo.model.SendNumRequest;
import com.demo.infy.demo.model.SendNumResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value="/api/numberoperations")
public class DemoController {
    @PostMapping(consumes = {"application/xml", "application/json"}, produces = {"application/xml", "application/json"})
    public ResponseEntity<SendNumResponse> sendData(@RequestBody SendNumRequest sendNumRequest) throws JsonProcessingException {

        int sum = 0;
        int avg = 0;
        Integer [] greaterThnAvg ={11};
        List<Integer> numList=new ArrayList<>();
        int n = sendNumRequest.getInput().length;
        for (int i = 0; i < n; i++) {
            sum += sendNumRequest.getInput()[i];
        }
        avg = sum / n;
        int k = 0;
        for (int j : sendNumRequest.getInput()) {
            {
                if (j > avg)
                    numList.add(j);
            }
        }
        Integer[] intArray = new Integer[numList.size()];
        intArray = numList.toArray(intArray);
        SendNumResponse sendNumResponse=new SendNumResponse();
        sendNumResponse.setAverage(avg);
        sendNumResponse.setGreater(intArray);
        sendNumResponse.setSum(sum);
        ObjectMapper objectMapper=new ObjectMapper();
       ResponseEntity r= ResponseEntity.status(HttpStatus.OK).body(objectMapper.writeValueAsString(sendNumResponse));
        return r;
    }
}